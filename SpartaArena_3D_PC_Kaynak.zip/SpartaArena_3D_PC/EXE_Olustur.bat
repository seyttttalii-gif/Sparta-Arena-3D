@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
where python >nul 2>nul
if errorlevel 1 (
  echo Python kurulu degil. Python 3.11 kur ve Add Python to PATH sec.
  pause
  exit /b 1
)
echo [1/4] Kutuphaneler kuruluyor...
python -m pip install --upgrade pip
python -m pip install -r requirements-build.txt
if errorlevel 1 goto fail

echo [2/4] 3D Sparta Arena EXE olusturuluyor...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name SpartaArena --collect-all panda3d --collect-all direct --add-data "assets;assets" --add-data "legacy_v57;legacy_v57" --icon "assets\SpartaArena.ico" --distpath dist --workpath build\panda --specpath build\spec3d main.py
if errorlevel 1 goto fail

echo [3/4] Orijinal V57 modu EXE olusturuluyor...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name SpartaArenaV57 --collect-all pygame --add-data "assets;assets" --icon "assets\SpartaArena.ico" --distpath dist --workpath build\pygame --specpath build\specv57 legacy_v57\main.py
if errorlevel 1 goto fail

echo [4/4] Tamamlandi. EXE dosyalari dist klasorunde.
echo SpartaArena.exe = gercek 3D arena
echo SpartaArenaV57.exe = orijinal V57 tum modlar
explorer "%CD%\dist"
pause
exit /b 0
:fail
echo Derleme basarisiz. Hata metnini kaydet ve destek iste.
pause
exit /b 1
