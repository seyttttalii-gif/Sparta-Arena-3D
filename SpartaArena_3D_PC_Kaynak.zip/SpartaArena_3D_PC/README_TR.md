# SPARTA ARENA — Gerçek 3D PC + V57 Tam İçerik

Bu paket, tek bir oyuna geçiş noktası verir; iki ayrı Windows uygulaması üretir:

- **SpartaArena.exe:** Panda3D ile gerçek 3D arena, üçüncü şahıs kamera, üç boyutlu savaşçı modelleri, ışıklandırma, arenanın mimarisi, düşman AI'sı, klasik tur, Tepenin Kralı, Boss Savaşı ve Sonsuz Mod.
- **SpartaArenaV57.exe:** Yüklenen/optimize edilen Pygame V57 kaynak kodunun orijinal özellikleri, menüleri, kayıtları ve modları. Dünya fethi, şehirler, deniz sistemi, balıkçılık, mağaza, iksirler, başarımlar ve diğer V57 sistemleri bu programda korunmuştur.

## Önemli kapsam notu

Bu paket, V57'nin tüm kampanya sistemlerini bir gecede 3D motora bire bir taşımış gibi davranmaz. Yeni 3D arena gerçek zamanlı 3D geometri/ışıklandırma kullanır ve belirtilen dört savaş modunu oynanabilir şekilde içerir. V57'nin geniş dünya/deniz/mağaza/ilerleme menüleri, özellikleri kaybetmemek için ayrı orijinal V57 uygulamasında korunur; bu sistemlerin tamamı henüz 3D'ye göçürülmüş değildir. Orijinal Android projesi `original_v57_source/` klasöründedir.

## Kaynak koddan çalıştırma

Python 3.11 veya 3.12 önerilir. Windows Terminal veya Komut İstemi'nde bu klasöre gel:

```bat
python -m pip install -r requirements.txt
python main.py
```

3D ana menüdeki **V57 TAM İÇERİK** seçeneği kaynak modunda `legacy_v57/main.py` dosyasını açar.

## Windows EXE üretme

İnternet bağlantısı gerekir; Panda3D ve PyInstaller indirilir. `EXE_Olustur.bat` dosyasına çift tıkla ya da GitHub Actions'ı çalıştır. Üretilen `SpartaArena.exe` ve `SpartaArenaV57.exe` aynı klasörde durmalıdır.

## 3D kontrolleri

Varsayılan: W/A/S/D hareket, fare sol tuş saldırı, Shift blok, Q iksir, E tam-can iksiri, Esc duraklat. **Ayarlar → Tuş Atama** bölümünden eyleme tıklayıp yeni klavye tuşu veya fare düğmesi seçilir; ayar `%LOCALAPPDATA%/SpartaArena/settings_3d.json` dosyasına kaydedilir. Grafik kalitesi seçeneği de bulunmaktadır.

## Optimizasyonlar

- Panda3D gerçek 3D çizimi ve hafif, prosedürel low-poly modeller; harici büyük model indirmesi yok.
- 60 FPS hedefi, sınırlı zaman adımı, düşük maliyetli arena geometrisi ve sabit dünya önbelleği.
- Kalite ayarına göre sütun/çevre geometrisi yoğunluğu.
- Ayar ve ilerleme JSON'larında geçici dosya + atomik `os.replace` kayıt yöntemi.
- V57 Pygame sürümünde ayrı önbellekleme, yeniden kullanılan çizim yüzeyleri ve kayıt iyileştirmeleri.

FPS artışı donanıma bağlıdır; burada gerçek Windows donanımında benchmark yapılmadı. İnternet çok oyunculusu hazır bir servis olarak dahil değildir; mevcut backend kaynakları ayrıca yapılandırma gerektirir.

## GitHub Actions ile iki EXE üretme

Bu paket ZIP olarak üretildiği için deponun ana dizinine `SpartaArena_3D_PC_Kaynak.zip` adıyla yüklenmelidir. Ardından `.github/workflows/windows-build.yml` dosyasının içeriğini bu paketteki aynı yoldaki dosyayla değiştirip Commit changes yap. `Actions` sekmesinden **Sparta Arena 3D Windows Build → Run workflow** başlat. Sonuç başarılıysa `Sparta-Arena-Windows-3D` artifact'i iki EXE'yi birlikte içeren `SpartaArena-3D-PC.zip` dosyasını verir.
